package com.wavesplatform.wallet.payload;

public class WavesBalance {
    public String address;
    public long balance;
}
