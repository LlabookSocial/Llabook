package com.wavesplatform.wallet.ui.transactions;

public class ItemTransaction {
}
